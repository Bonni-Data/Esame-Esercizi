# Organizzazioni e Società Digitali (Computer & Society) a.a. 2020/21 - Universita di Milano - SPS

Nel branch Lezione_11novembre e' presente il seguente file :
- Esercizio6_7novembre.ipynb relativo a esercitazioni con funzioni di pandas (join, index, groupby, query)

Si ringrazia l'autrice, Marta Andreoletti, per averlo condiviso.
