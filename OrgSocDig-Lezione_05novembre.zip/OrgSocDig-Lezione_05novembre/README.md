# Organizzazioni e Società Digitali (Computer & Society) a.a. 2020/21 - Universita di Milano - SPS

Nel branch Lezione_05novembre sono presenti i seguenti file:
- dataset Excel relativi all'Esercizio 6 (Join di dataset)
- i risultanti csv dopo aver lavorato sui dati (attenzione all'errore!!!)
- il notebook Esercizio6_join.ipynb relativo alla join e con diverse funzioni supplementari
- il notebook EsPivot.ipynb con un esercizio supplementare rispetto ai contenuti del notebook 03_09 Pivot Tables del libro 
